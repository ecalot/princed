
#ifndef _MEMORY_H_
#define _MEMORY_H_

#include <stdlib.h>

//Reserves a memory space to allocate an image
unsigned char* getMemory(int size);

#endif

